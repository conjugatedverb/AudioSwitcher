// AudioSwitcherApp.swift
import SwiftUI

@main
struct AudioSwitcherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
